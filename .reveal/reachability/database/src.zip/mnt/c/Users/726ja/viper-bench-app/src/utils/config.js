'use strict';

module.exports = {
  port: process.env.PORT || 3000,
  // 캐시/세션 TTL은 배포 시 고정되는 운영 설정값이며 요청 단위로 바뀌지 않음
  cacheTtl: '2 days',
  requestLogTtl: '30 minutes',
};
