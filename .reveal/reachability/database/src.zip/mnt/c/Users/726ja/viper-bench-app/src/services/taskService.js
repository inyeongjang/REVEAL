'use strict';

const _ = require('lodash');

const TASKS = [
  { id: 1, title: 'Design API schema', status: 'done', priority: 2 },
  { id: 2, title: 'Write integration tests', status: 'in_progress', priority: 1 },
  { id: 3, title: 'Deploy staging environment', status: 'todo', priority: 3 },
  { id: 4, title: 'Set up monitoring', status: 'todo', priority: 4 },
];

// 아래 함수들은 모두 lodash의 "안전한" 유틸리티만 사용함.
// GHSA-35jh(_.template), GHSA-p6mc(_.zipObjectDeep), GHSA-xxjr/GHSA-f23m(_.unset/_.omit)가
// 지목하는 함수는 이 파일뿐 아니라 프로젝트 전체에서 호출되지 않음.

function listTasks({ status } = {}) {
  const filtered = status ? _.filter(TASKS, { status }) : TASKS;
  return _.sortBy(filtered, 'priority');
}

function groupByStatus() {
  return _.groupBy(TASKS, 'status');
}

function paginate(items, pageSize) {
  return _.chunk(items, pageSize);
}

function pickSummaryFields(task) {
  // 취약 함수인 _.omit이 아니라 _.pick(안전)을 사용
  return _.pick(task, ['id', 'title', 'status']);
}

module.exports = { listTasks, groupByStatus, paginate, pickSummaryFields };
