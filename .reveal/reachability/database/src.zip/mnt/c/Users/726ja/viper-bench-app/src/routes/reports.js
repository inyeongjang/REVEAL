'use strict';

const url = require('url');
const { renderReport } = require('../services/reportService');
const { listTasks } = require('../services/taskService');

function reportsHandler(req, res) {
  const { query } = url.parse(req.url, true);
  // query.status(사용자 입력)는 listTasks의 필터 조건으로만 쓰이고,
  // 그 결과 배열은 renderReport에서 템플릿 데이터로만 소비됨.
  const tasks = listTasks({ status: query.status });
  const report = renderReport(tasks);
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end(report);
}

module.exports = reportsHandler;
