'use strict';

const http = require('http');
const router = require('./router');
const requestLogger = require('./middleware/requestLogger');
const config = require('./utils/config');
const { createLogger } = require('./utils/logger');

const log = createLogger('server');

const server = http.createServer((req, res) => {
  requestLogger(req, res, () => router(req, res));
});

if (require.main === module) {
  server.listen(config.port, () => {
    log(`TaskFlow API listening on port ${config.port}`);
  });
}

module.exports = server;
