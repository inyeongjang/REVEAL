'use strict';

const url = require('url');
const { listTasks, groupByStatus } = require('../services/taskService');

function tasksHandler(req, res) {
  const { query } = url.parse(req.url, true);
  const tasks = listTasks({ status: query.status });
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(tasks));
}

function tasksSummaryHandler(req, res) {
  const summary = groupByStatus();
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(summary));
}

module.exports = { tasksHandler, tasksSummaryHandler };
