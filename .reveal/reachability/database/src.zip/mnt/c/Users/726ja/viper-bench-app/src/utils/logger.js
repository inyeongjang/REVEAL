'use strict';

const debug = require('debug');

function createLogger(namespace) {
  return debug(`taskflow:${namespace}`);
}

module.exports = { createLogger };
