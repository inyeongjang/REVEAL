'use strict';

const ms = require('ms');
const { createLogger } = require('../utils/logger');
const config = require('../utils/config');

const log = createLogger('http');

// 서버 기동 시 1회, 정적 config 문자열만 ms()에 전달됨.
// 사용자 요청(req.query, req.body, req.headers)에서 온 값은
// 이 파일 어디에서도 ms()의 인자로 흘러들어가지 않음.
const cacheTtlMs = ms(config.cacheTtl);
const requestLogTtlMs = ms(config.requestLogTtl);

function requestLogger(req, res, next) {
  const start = Date.now();

  res.on('finish', () => {
    const elapsed = Date.now() - start;
    // 로그 메시지에 포함되는 값: method, url path, statusCode, elapsed(서버 계산값)뿐.
    // 요청 본문/쿼리 파라미터는 로그에 포함하지 않음.
    log(
      `${req.method} ${req.url} ${res.statusCode} ${elapsed}ms ` +
        `(cacheTtl=${cacheTtlMs}ms, logTtl=${requestLogTtlMs}ms)`
    );
  });

  next();
}

module.exports = requestLogger;
