'use strict';

const _ = require('lodash');

// GHSA-35jh-r3h4-6jhm / GHSA-r5fr-rjxr-66jc의 공격 지점은
// `options.imports`의 "키 이름"(변수명)이 공격자 통제 하에 있을 때 발생함.
// 여기서는 템플릿 문자열과 imports 키 이름("_ ") 모두 소스코드에 고정돼 있고,
// 사용자 요청에서 올 수 있는 값(tasks 배열의 title/status)은 오직
// 템플릿 "데이터"로만 삽입됨 — Function() 생성자의 파라미터/키 이름에는
// 어떤 경로로도 도달하지 않음.
const REPORT_TEMPLATE =
  'Task Report\n' +
  '<% _.forEach(tasks, function(t) { %>' +
  '- <%- t.title %> (<%- t.status %>)\n' +
  '<% }); %>';

const compiled = _.template(REPORT_TEMPLATE, {
  imports: { _: _ }, // 정적 키 이름, attacker-controlled 아님
});

function renderReport(tasks) {
  return compiled({ tasks });
}

module.exports = { renderReport };
