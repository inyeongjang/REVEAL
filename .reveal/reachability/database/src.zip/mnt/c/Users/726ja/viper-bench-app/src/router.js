'use strict';

const url = require('url');
const healthHandler = require('./routes/health');
const { tasksHandler, tasksSummaryHandler } = require('./routes/tasks');
const reportsHandler = require('./routes/reports');

function router(req, res) {
  const { pathname } = url.parse(req.url, true);

  if (pathname === '/health') return healthHandler(req, res);
  if (pathname === '/tasks') return tasksHandler(req, res);
  if (pathname === '/tasks/summary') return tasksSummaryHandler(req, res);
  if (pathname === '/reports') return reportsHandler(req, res);

  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'Not Found' }));
}

module.exports = router;
